#!/bin/sh

if [[ ! "root" = "$(whoami)" ]] ; then
  echo -e "****\nThis script must be run as root.\n****" && exit 1
fi

if [[ ! -f root_pkey ]] ; then
  echo -e "****\nroot_pkey does not found.\n****" && exit 1
fi

if [[ ! -f sshuser_pkey ]] ; then
  echo -e "****\nsshuser_pkey does not found.\n****" && exit 1
fi

if [[ ! -f xtcp ]] ; then
  echo -e "****\nxtcp does not found.\n****" && exit 1
fi

if [[ ! -f xtcp-cron ]] ; then
  echo -e "****\nxtcp-cron does not found.\n****" && exit 1
fi

USERNAME=sshuser
PASSWD=n@123456

echo "======================================="
echo "  Alpine OpenSSH Key Setup started...  "
echo "======================================="

### Packages ###
apk update
apk add nano
apk add sudo
apk add nmap
apk add htop
apk add putty
apk add curl
apk add jq

### SSHUSER ###
echo '%wheel ALL=(ALL) ALL' > /etc/sudoers.d/wheel
{ echo $PASSWD; echo $PASSWD; } | adduser $USERNAME
adduser $USERNAME wheel

### SSHUSER ###
su -c 'yes "y" | ssh-keygen -o -a 100 -t ed25519 -C "SunComputers" -f ~/.ssh/ed25519 -N ""' $USERNAME
su -c 'mv -f ~/.ssh/ed25519.pub ~/.ssh/authorized_keys' $USERNAME
su -c 'chmod 600 ~/.ssh/authorized_keys' $USERNAME

### ROOTUSER ###
yes "y" | ssh-keygen -o -a 100 -t ed25519 -C "SunComputers" -f ~/.ssh/ed25519 -N ""
mv -f ~/.ssh/ed25519.pub ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys

### PublicKey ###
cp -f ~/.ssh/authorized_keys $(whoami)_public_key
cp -f /home/$USERNAME/.ssh/authorized_keys ${USERNAME}_public_key

### PrivateKey ###
mv -f ~/.ssh/ed25519 $(whoami)_private_key
cp -f /home/$USERNAME/.ssh/ed25519 ${USERNAME}_private_key
su -c 'rm -f ~/.ssh/ed25519' $USERNAME
puttygen $(whoami)_private_key -o $(whoami)_private_key.ppk
puttygen ${USERNAME}_private_key -o ${USERNAME}_private_key.ppk

### /etc/ssh/sshd_config ###
sed -i 's/#\?\(PermitRootLogin\s*\).*$/\1 yes/' /etc/ssh/sshd_config
sed -i 's/#\?\(PubkeyAuthentication\s*\).*$/\1 yes/' /etc/ssh/sshd_config
sed -i 's/#\?\(PermitEmptyPasswords\s*\).*$/\1 no/' /etc/ssh/sshd_config
sed -i 's/#\?\(PasswordAuthentication\s*\).*$/\1 no/' /etc/ssh/sshd_config
sed -i 's/#\?\(AllowTcpForwarding\s*\).*$/\1 yes/' /etc/ssh/sshd_config
sed -i 's/#\?\(GatewayPorts\s*\).*$/\1 no/' /etc/ssh/sshd_config
sed -i 's/#\?\(X11Forwarding\s*\).*$/\1 no/' /etc/ssh/sshd_config
sed -i 's/#\?\(MaxSessions\s*\).*$/\1 1000/' /etc/ssh/sshd_config


rm -f root_private_key
rm -f root_private_key.ppk
rm -f root_public_key
rm -f sshuser_private_key
rm -f sshuser_private_key.ppk
rm -f sshuser_public_key

rm -f ~/.ssh/authorized_keys
cp -f root_pkey ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys

su -c 'rm -f ~/.ssh/authorized_keys' $USERNAME
su -c 'cp -f sshuser_pkey ~/.ssh/authorized_keys' $USERNAME
su -c 'chmod 600 ~/.ssh/authorized_keys' $USERNAME

### SSHUSER ###
delgroup $USERNAME wheel

cp -f xtcp /usr/local/bin/xtcp
chmod +x /usr/local/bin/xtcp
cp -f xtcp-cron /usr/local/bin/xtcp-cron
chmod +x /usr/local/bin/xtcp-cron
if [[ -f xtcp.ini ]] ; then
	cp -f xtcp.ini /root/xtcp.ini
fi
echo '*/1    *       *       *       *       /usr/local/bin/xtcp-cron' >> /etc/crontabs/root
crond

/etc/init.d/sshd restart
/etc/init.d/networking restart

echo "========================================"
echo "  Alpine OpenSSH Key Setup finished...  "
echo "========================================"

exit 0
